#include "gui/gui.h"
#include <stdio.h>

int main(int argc, char** argv) {
    printf("Loaching gui... \n");
    init_interface(argc, argv);
}