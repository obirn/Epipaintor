#ifndef DECOLOR_H_
#define DECOLOR_H_

#include <err.h>
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <gtk/gtk.h>
#include "GTK/gtk.h"

#endif

