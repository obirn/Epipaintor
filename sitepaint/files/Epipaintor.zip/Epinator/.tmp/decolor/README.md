Decolor
===================================
How to use Decolor ?

- Use the command make without any argument.
- Then type ./decolor.
- An interface will now appear and allow you to modify and create some images.







You can type 'make clean' to clean every trash file and compiled file

Our Website
https://topagrume.github.io/decolor_web/accueil.html
